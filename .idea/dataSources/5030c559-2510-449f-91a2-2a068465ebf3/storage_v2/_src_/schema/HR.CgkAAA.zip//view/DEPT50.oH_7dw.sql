create view DEPT50 as
  select employee_id "empno", last_name "employee", department_id "deptno" from employees where department_id = 50 with read only
/

