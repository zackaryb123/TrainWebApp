create view EMPLOYEES_VU1 as
  select last_name "Employees", department_id from employees
/

