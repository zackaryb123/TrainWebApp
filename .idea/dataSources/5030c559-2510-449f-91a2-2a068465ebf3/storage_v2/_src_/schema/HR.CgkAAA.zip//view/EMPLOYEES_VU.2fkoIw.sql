create view EMPLOYEES_VU as
  select last_name "Employee", department_id from employees
/

