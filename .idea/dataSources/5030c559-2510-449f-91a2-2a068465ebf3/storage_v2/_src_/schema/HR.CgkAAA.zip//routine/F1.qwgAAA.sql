create FUNCTION F1
  (a IN NUMBER, b IN NUMBER)
  RETURN NUMBER
  IS
  result NUMBER(10);
  BEGIN
    result := a + b;
    return result;
  end;
/

